using EventEase.Models;
using EventEase.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Essential services
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("AzureSQL")));

// Blob Storage Service
// Update this in Program.cs
builder.Services.AddScoped<BlobStorageService>(provider =>
{
    var config = provider.GetRequiredService<IConfiguration>();
    return new BlobStorageService(
        connectionString: config.GetConnectionString("AzureBlobStorage") ??
            throw new InvalidOperationException("AzureBlobStorage connection string is missing"),
        containerName: config["BlobStorage:ContainerName"] ??
            throw new InvalidOperationException("Container name is missing"),
        allowedExtensions: config["BlobStorage:AllowedExtensions"] ?? ".jpg,.jpeg,.png",
        maxFileSizeMB: int.TryParse(config["BlobStorage:MaxFileSizeMB"], out var maxSize) ? maxSize : 5
    );
});

var app = builder.Build();

// Middleware pipeline
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();