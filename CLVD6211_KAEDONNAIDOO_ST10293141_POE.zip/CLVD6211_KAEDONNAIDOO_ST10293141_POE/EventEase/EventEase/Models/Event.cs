﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Http;

namespace EventEase.Models
{
    public class Event
    {
        [Key]
        public int EventId { get; set; }

        [Required(ErrorMessage = "Event name is required")]
        [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters")]
        public string Name { get; set; }

        [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
        public string? Description { get; set; }

        [Display(Name = "Image URL")]
        public string? ImageUrl { get; set; }

        [Display(Name = "Event Type")]
        public int? EventTypeId { get; set; }

        // Navigation properties
        [ForeignKey("EventTypeId")]
        public EventType? EventType { get; set; }

        public ICollection<Booking>? Bookings { get; set; }

        // Not mapped property for file upload
        [NotMapped]
        [Display(Name = "Event Image")]
        public IFormFile? ImageFile { get; set; }
    }
}