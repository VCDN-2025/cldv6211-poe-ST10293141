﻿using Microsoft.EntityFrameworkCore;
using EventEase.Models;

namespace EventEase.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Venue> Venues { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<EventType> EventTypes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure Venue entity
            modelBuilder.Entity<Venue>(entity =>
            {
                entity.HasKey(v => v.VenueId);
                entity.Property(v => v.Name).IsRequired().HasMaxLength(100);
                entity.Property(v => v.Location).IsRequired().HasMaxLength(100);
                entity.Property(v => v.Capacity).IsRequired();
                entity.Property(v => v.IsActive).HasDefaultValue(true);
                entity.Property(v => v.Availability).HasDefaultValue(true);
            });

            // Configure Event entity
            modelBuilder.Entity<Event>(entity =>
            {
                entity.HasKey(e => e.EventId);
                entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Description).HasMaxLength(500);
                entity.HasOne(e => e.EventType)
                      .WithMany(et => et.Events)
                      .HasForeignKey(e => e.EventTypeId)
                      .OnDelete(DeleteBehavior.SetNull);
            });

            // Configure Booking entity
            modelBuilder.Entity<Booking>(entity =>
            {
                entity.HasKey(b => b.BookingId);
                entity.Property(b => b.CustomerName).IsRequired().HasMaxLength(100);
                entity.Property(b => b.CustomerEmail).IsRequired().HasMaxLength(100);

                // Configure relationship with Venue
                entity.HasOne(b => b.Venue)
                      .WithMany(v => v.Bookings)
                      .HasForeignKey(b => b.VenueId)
                      .OnDelete(DeleteBehavior.Restrict);

                // Configure relationship with Event
                entity.HasOne(b => b.Event)
                      .WithMany(e => e.Bookings)
                      .HasForeignKey(b => b.EventId)
                      .OnDelete(DeleteBehavior.Restrict);

                // Add check constraint for date validation
                entity.ToTable(b => b.HasCheckConstraint(
                    "CHK_EndAfterStart",
                    "[EndDateTime] > [StartDateTime]"
                ));
            });

            // Configure EventType entity
            modelBuilder.Entity<EventType>(entity =>
            {
                entity.HasKey(et => et.EventTypeId);
                entity.Property(et => et.Name).IsRequired().HasMaxLength(50);
                entity.Property(et => et.Description).HasMaxLength(255);
            });

            // Seed initial data
            modelBuilder.Entity<EventType>().HasData(
                new EventType { EventTypeId = 1, Name = "Conference", Description = "Business conferences and seminars" },
                new EventType { EventTypeId = 2, Name = "Wedding", Description = "Wedding ceremonies and receptions" },
                new EventType { EventTypeId = 3, Name = "Concert", Description = "Music concerts and performances" },
                new EventType { EventTypeId = 4, Name = "Exhibition", Description = "Art and product exhibitions" },
                new EventType { EventTypeId = 5, Name = "Corporate", Description = "Corporate meetings and events" }
            );

            // Seed sample venues
            modelBuilder.Entity<Venue>().HasData(
                new Venue
                {
                    VenueId = 1,
                    Name = "Grand Ballroom",
                    Location = "123 Main Street",
                    Capacity = 500,
                    IsActive = true,
                    Availability = true
                },
                new Venue
                {
                    VenueId = 2,
                    Name = "Conference Center",
                    Location = "456 Business Ave",
                    Capacity = 200,
                    IsActive = true,
                    Availability = true
                }
            );

            // Seed sample events
            modelBuilder.Entity<Event>().HasData(
                new Event
                {
                    EventId = 1,
                    Name = "Tech Summit 2023",
                    Description = "Annual technology conference",
                    EventTypeId = 1
                },
                new Event
                {
                    EventId = 2,
                    Name = "Smith-Johnson Wedding",
                    Description = "Wedding ceremony and reception",
                    EventTypeId = 2
                }
            );
        }

        public override int SaveChanges()
        {
            // Add any pre-save logic here if needed
            return base.SaveChanges();
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            // Add any async pre-save logic here if needed
            return await base.SaveChangesAsync(cancellationToken);
        }
    }
}