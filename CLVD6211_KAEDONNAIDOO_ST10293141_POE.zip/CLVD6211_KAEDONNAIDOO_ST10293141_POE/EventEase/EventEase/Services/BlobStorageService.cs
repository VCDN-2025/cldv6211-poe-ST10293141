﻿// Services/BlobStorageService.cs
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.AspNetCore.Http;

namespace EventEase.Services
{
    public class BlobStorageService
    {
        private readonly BlobServiceClient _blobServiceClient;
        private readonly string _containerName;
        private readonly string[] _allowedExtensions;
        private readonly long _maxFileSizeBytes;

        public BlobStorageService(string connectionString,
                                 string containerName,
                                 string allowedExtensions,
                                 int maxFileSizeMB)
        {
            _blobServiceClient = new BlobServiceClient(connectionString);
            _containerName = containerName;
            _allowedExtensions = allowedExtensions.Split(',');
            _maxFileSizeBytes = maxFileSizeMB * 1024 * 1024;
        }

        public async Task<string> UploadFileAsync(IFormFile file, string fileName)
        {
            // Validate file
            if (file == null || file.Length == 0)
                throw new ArgumentException("No file uploaded");

            if (file.Length > _maxFileSizeBytes)
                throw new ArgumentException($"File exceeds maximum size of {_maxFileSizeBytes / 1024 / 1024}MB");

            var fileExtension = Path.GetExtension(file.FileName).ToLower();
            if (!_allowedExtensions.Contains(fileExtension))
                throw new ArgumentException($"Invalid file type. Allowed: {string.Join(", ", _allowedExtensions)}");

            // Create container if not exists
            var containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
            await containerClient.CreateIfNotExistsAsync(PublicAccessType.Blob);

            // Generate unique filename
            var blobName = $"{Guid.NewGuid()}{fileExtension}";
            var blobClient = containerClient.GetBlobClient(blobName);

            // Upload file
            using (var stream = file.OpenReadStream())
            {
                await blobClient.UploadAsync(stream, new BlobHttpHeaders
                {
                    ContentType = file.ContentType
                });
            }

            return blobClient.Uri.ToString();
        }

        internal async Task DeleteFileAsync(string blobName)
        {
            throw new NotImplementedException();
        }
    }
}